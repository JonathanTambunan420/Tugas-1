<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'] ?? '';
    $quantity = $_POST['quantity'] ?? 0;
    $price = $_POST['price'] ?? '';

    if ($name != '') {
        $sql = "INSERT INTO items (name, quantity, price) VALUES ('$name', $quantity, '$price')";
        if ($conn->query($sql) === TRUE) {
            echo "Item added successfully.";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Data tidak lengkap!";
    }
} else {
    echo "Hanya menerima POST!";
}
?>
