document.addEventListener("DOMContentLoaded", () => {
  loadItems();

  document.getElementById("itemForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const quantity = document.getElementById("quantity").value;
    const price = document.getElementById("price").value;

    const formData = new FormData();
    formData.append("name", name);
    formData.append("quantity", quantity);
    formData.append("price", price);

    fetch("api/add_item.php", {
      method: "POST",
      body: formData,
    })
      .then((res) => res.text())
      .then((response) => {
        console.log("Response dari PHP:", response);
        document.getElementById("itemForm").reset();
        loadItems();
      });
  });
});

function loadItems() {
  fetch("api/get_items.php")
    .then((res) => res.json())
    .then((data) => {
      const tbody = document.querySelector("#inventoryTable tbody");
      tbody.innerHTML = "";
      data.forEach((item) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${item.name}</td>
          <td>${item.quantity}</td>
          <td>${item.price}</td>
          <td><button class="delete-btn" onclick="deleteItem(${item.id})">Delete</button></td>
        `;
        tbody.appendChild(row);
      });
    });
}

function deleteItem(id) {
  const formData = new FormData();
  formData.append("id", id);

  fetch("api/delete_item.php", {
    method: "POST",
    body: formData,
  })
    .then((res) => res.text())
    .then(() => loadItems());
}
